# 轻账｜中文记账应用

一个可在个人电脑运行的中文记账 Web 应用，包含日历记账、统计、分类管理、预算、个人账户和本地 SQLite 保存。

## 快速启动

- Windows：安装 Python 3.10 或更新版本，双击 `启动轻账.bat`，再访问 <http://127.0.0.1:4173>。
- macOS / Linux：在此目录运行 `python3 server.py`，再访问 <http://127.0.0.1:4173>。
- 命令行启动及数据保存说明见 [使用指南](使用指南.md)。

服务运行期间请保持启动窗口打开；按 `Ctrl+C` 停止服务。应用不需要 npm 安装或外部数据库。

## 数据位置

创建个人账户后，账户和账本数据保存在运行服务的电脑上的 `.qingzhang-data/accounts.sqlite3`。未登录时，数据保存在当前浏览器的本地存储中。这个目录包含私人数据，不要发送给他人或提交到 GitHub；`.gitignore` 已将它排除。

## 在 GitHub 上分享

访问者可从仓库页面选择 **Code → Download ZIP**，解压后按 [GitHub 本地运行指南](GitHub本地运行指南.md) 操作；也可直接下载 [最新本地运行包](release/轻账-本地版.zip)。要把本项目首次发布到自己的 GitHub 账户，按该指南中的“发布者：首次上传项目”步骤进行。

公开仓库用于分享代码和下载本地版本。当前应用需要 Python 服务和 SQLite 文件，因此不能只靠 GitHub Pages 运行成多人共用的网站；将来发布在线版时，需要部署支持 Python 后端和持久化磁盘的主机。

## 可选验证

在项目目录运行以下命令，可检查核心金额和周期计算、页面渲染逻辑及账户服务 API：

```powershell
node verify-core.cjs
node verify-render.cjs
python verify-server.py
```

页面与交互验证也覆盖了统计折线图的自定义回看范围，以及动态日预算、单日覆盖和恢复默认值。
